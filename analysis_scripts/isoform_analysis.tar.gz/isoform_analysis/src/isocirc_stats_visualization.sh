#!/bin/bash

# This is a pipeline for visualizing isoCirc statistics:
#	* exon number per isoform
#	* transcript length per isoform
#	* read count per isoform per tissue

# Parse input arguments
input="$1"
plotdir="$2"

# Establish working directories
data=$(dirname "$input")
home=$(dirname "$data")
src="$home/src"

prefix=$(basename "$input" | cut -d '.' -f1)

# Exon number per isoform
Rscript "$src/exon_number_per_isoform_CDF.R" "$input" "$plotdir/$prefix.exon_number_per_isoform_CDF.pdf"

# Transcript length per isoform
Rscript "$src/transcript_length_per_isoform_CDF.R" "$input" "$plotdir/$prefix.transcript_length_per_isoform_CDF.pdf"

# Read count per isoform per tissue
Rscript "$src/read_count_per_isoform_per_tissue_CDF.R" "$input" "$plotdir/$prefix.read_count_per_isoform_per_tissue_CDF.pdf"