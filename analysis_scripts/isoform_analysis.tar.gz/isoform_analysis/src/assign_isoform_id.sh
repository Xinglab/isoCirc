#!/bin/bash

# Function that will assign IDs to each isoform of a given gene using the following format: [gene name].circRNA.[rank]
#	The rank is determined by the following tier list of rules:
#		1. Highest median isoform read count across 12 human tissues
#		2. Highest mean isoform read count across 12 human tissues
# For intergenic circRNA isoforms, we assign IDs using the following format: NA.[chromosome #].circRNA.[sorted index]
#	The sorted index is determined by sorting the genomic coordinates of the back-splice junction

assign_isoform_id()
{
	fileprefix=$(basename "$1")
	
	# Sequential processing of input gene list
	while read gene; do
		awk -v "gene=$gene" '{if($5==gene){print}}' "$tmpdir/$outprefix.with_genes.expanded.tsv" | cut -f1-4,6- | tr ',' '_' | perl -pe '$i = 0; s/\t/_/ while $i++ < 5' > "$tmpdir/$fileprefix.partial.key"
		cut -f4- "$tmpdir/$fileprefix.partial.key" | awk '{
			# Calculate the median/mean isoform read count across 12 human tissues
			sum=0;
			n=split($0,a);
			asort(a);
			for(i=1;i<=n;i++) sum+=a[i];
			median=n%2?a[n/2+1]:(a[n/2]+a[n/2+1])/2;
			mean=sum/n;
			printf("%s\t%s\n",median,mean);
		}' | paste - "$tmpdir/$fileprefix.partial.key" | sort -k1,1rg -k2,2rg | nl | tr -s ' ' | sed "s/^ /$gene.circRNA./" | cut -f1,4 >> "$tmpdir/$fileprefix.key"
		rm "$tmpdir/$fileprefix.partial.key"
	done < "$1"
}
export tmpdir
export outprefix
export -f assign_isoform_id

# Parse input arguments
inputfile="$1"
threads="$2"

# Establish working directories
data=$(dirname "$inputfile")
home=$(dirname "$data")
tmpdir="$home/tmp"

mkdir -p "$tmpdir"

# Construct label for output file
outprefix=$(basename "$inputfile" | rev | cut -d '.' -f2- | rev)
outsuffix=$(basename "$inputfile" | rev | cut -d '.' -f1 | rev)
outfile="$data/$outprefix.withID.$outsuffix"

# Copy file header over to output file
head -n 1 "$inputfile" | awk 'END{printf("%s\t%s\n","isoformID",$0)}' > "$outfile"

# Partition isoforms based on gene assignment 
#	Case 1. isoform is assigned to at least one gene
#	Case 2. isoform is not assigned to a gene
isofile1="$tmpdir/$outprefix.with_genes.tsv"
isofile2="$tmpdir/$outprefix.no_genes.tsv"

tail -n +2 "$inputfile" | awk '{if($6!="NA"){print}}' > "$isofile1"
tail -n +2 "$inputfile" | awk '{if($6=="NA"){print}}' > "$isofile2"

# Case 1. Processing isoforms assigned to at least one gene

# Expansion of annotation file such that each isoform has one gene
awk '{
	n=split($6,genearr,",");
	split($4,strandarr,",");
	for(i=1;i<=n;i++) {
		out=$1"\t"$2"\t"$3"\t"strandarr[i]"\t"genearr[i]"\t"$8"\t"$9;
		for(j=33;j<=NF;j++) {
			out=out"\t"$j;
		}
		print out;
	}
}' "$isofile1" > "$tmpdir/$outprefix.with_genes.expanded.tsv"

# Construct isoCirc gene list
cut -f5 "$tmpdir/$outprefix.with_genes.expanded.tsv" | sort | uniq > "$tmpdir/$outprefix.genes.list"

# Split isoCirc gene list for parallel processing
filewc=$(wc -l < "$tmpdir/$outprefix.genes.list")
linesperfile=$(awk 'BEGIN {printf("%.0f",('"$filewc"'+'"$threads"'-1)/'"$threads"')}')
split --lines="$linesperfile" "$tmpdir/$outprefix.genes.list" "$tmpdir/$outprefix.genes.list."

# Parallel processing of isoforms by gene
find "$tmpdir" -name "$outprefix.genes.list.*" -print0 | parallel -0 -n 1 -P "$threads" -I '{}' assign_isoform_id '{}'

# Processing of files generated during parallel processing
find "$tmpdir" -name "$outprefix.genes.list.*.key" | while read key; do
	cat "$key" >> "$tmpdir/$outprefix.output.key"
done

# Removal of intermediate files
rm $tmpdir/$outprefix.genes.list.*.key
rm $tmpdir/$outprefix.genes.list
rm $tmpdir/$outprefix.with_genes.expanded.tsv
rm $isofile1

# Case 2. Processing isoforms not assigned to a gene

# Assign IDs to isoforms without gene assignments using the following format: NA.[chromosome].circRNA.[index]
#	The index of the isoform is based on sorted genomic coordinates of the backsplice junction on a given chromosome (ignoring strandedness)
seq 1 22 | cat - <(echo -e "X\nY") | sed 's/^/chr/' | while read chr; do
	awk -v "chr=$chr" '{if($1==chr){print}}' "$isofile2" | cut -f1-4,8,9 | sort -k2,2g -k3,3g | tr ',' '_' | perl -pe '$i = 0; s/\t/_/ while $i++ < 5' | nl | tr -s ' ' | sed "s/^ /NA.$chr.circRNA./" >> "$tmpdir/$outprefix.output.key"
done

# Combine isoform IDs that refer to the same circRNA
awk '{printf("%s\t%s\n",$2,$1)}' "$tmpdir/$outprefix.output.key" | awk -F'\t' -v OFS='\t' '{x=$1;$1="";a[x]=a[x]$0}END{for(x in a)print x,a[x]}' | sed 's/\t\t/\t/' | tr '\t' ',' | perl -pe 's/,/\t/' > "$tmpdir/$outprefix.output.compressed.key"

# Map assigned isoform IDs to original input file
tail -n +2 "$inputfile" | awk 'BEGIN{FS="\t";OFS="\t"}{gsub(",","_",$8);gsub(",","_",$9);print}' | awk '{
	if(FNR==NR) {
		id[$1]=$2;
	}
	else{
		split($4,y,",");
		x=$1"_"$2"_"$3"_"y[1]"_"$8"_"$9;
		printf("%s\t%s\n",id[x],$0)
	}
}' "$tmpdir/$outprefix.output.compressed.key" - | awk 'BEGIN{FS="\t";OFS="\t"}{gsub("_",",",$9);gsub("_",",",$10);print}' >> "$outfile"

# Removal of intermediate files
rm $isofile2
rm $tmpdir/$outprefix.output.key
rm $tmpdir/$outprefix.output.compressed.key
rm -rf $tmpdir