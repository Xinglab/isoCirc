#!/usr/bin/Rscript

# This is a script for visualizing the distribution of exon number per circRNA isoform as a CDF
#	Isoforms are grouped based on categorizations of their BSJ/FSJs as follows:
#	* FSM/NIC - FSM/NIC
#	* FSM/NIC - NNC
#	* NNC - FSM/NIC
#	* NNC - NNC
#	* combined	
#
# For definitions of BSJ/FSJ categories, refer to the IsoCirc GitHub.
# Only circRNA isoforms with a valid gene assignment are plotted.
# The resulting output is a PDF


# Libraries:
suppressMessages(library(ggplot2))
suppressMessages(library(dplyr))

# Main:

# Parse command-line arguments
args = commandArgs(trailingOnly=TRUE)
input = args[1]
output = args[2]

#input = "isoCirc_hg19_12Tissues.isocirc.out"
#output = "isoCirc_hg19_12Tissues.exon_number_per_isoform_CDF.pdf"

# Read IsoCirc pipeline output as a data frame
df <- read.table(input,sep="\t",header=TRUE)

# Filter data frame for cases where there is a 'NA' gene assignment
#df <- df[!(is.na(df$geneName)),]

# Construct a smaller dataframe involving (1) BSJ category, (2) FSJ category, (3) block count
subsetDF <- df %>% select(BSJCate, FSJCate, blockCount)

# Collapse to create BSJ-FSJ feature
subsetDF$cate <- paste(subsetDF$BSJCate, subsetDF$FSJCate, sep="-")

# Group FSM with NIC

# Create a new category for combined
copySubsetDF <- data.frame(subsetDF)
copySubsetDF$cate <- rep("All-All", nrow(copySubsetDF))

finalDF <- data.frame()
finalDF <- rbind(finalDF, copySubsetDF)
colnames(finalDF) <- colnames(subsetDF)

# FSM/NIC-FSM/NIC 
tmpDF <- subsetDF[subsetDF$cate=="FSM-FSM" | subsetDF$cate=="NIC-FSM" | subsetDF$cate=="FSM-NIC" | subsetDF$cate=="NIC-NIC",]
tmpDF$cate <- rep("FSM/NIC-FSM/NIC",nrow(tmpDF))
finalDF <- rbind(finalDF, tmpDF)

#FSM/NIC-NNC
tmpDF <- subsetDF[subsetDF$cate=="FSM-NNC" | subsetDF$cate=="NIC-NNC",]
tmpDF$cate <- rep("FSM/NIC-NNC", nrow(tmpDF))
finalDF <- rbind(finalDF, tmpDF)

# NNC-FSM/NIC
tmpDF <- subsetDF[subsetDF$cate=="NNC-FSM" | subsetDF$cate=="NNC-NIC",]
tmpDF$cate <- rep("NNC-FSM/NIC", nrow(tmpDF))
finalDF <- rbind(finalDF, tmpDF)

#NNC/NNC
finalDF <- rbind(finalDF, subsetDF[subsetDF$cate=="NNC-NNC",])

# Annotate each label by counts
countDF <- data.frame(table(finalDF$cate))
colnames(countDF) <- c("class", "count")
finalDF$cate <- unlist(lapply(finalDF$cate, function(x) paste(x, paste("(",paste(as.character(format(countDF[countDF$class == x,]$count, big.mark = ",", scientific = FALSE)), ")", sep=""), sep=""), sep=" ")))

finalDF$cate <- as.factor(finalDF$cate)
finalDF$cate <- factor(finalDF$cate, levels = c(levels(finalDF$cate)[-1], levels(finalDF$cate)[1]))

# Establish plot theme:
theme_jack <- function (base_size = 12, base_family = "") {
theme_gray(base_size = base_size, base_family = base_family) %+replace%
  theme(
    panel.background = element_rect(fill=NULL),
    panel.grid.minor.y = element_line(size=0),
    panel.grid.minor.x = element_line(size=0),
    panel.grid.major = element_line(colour = "grey80",size=.2)
  )
}
theme_set(theme_jack())

# Establish axis limits:
xmin <- 0
xmax <- (floor(max(finalDF$blockCount)/5)+1)*5
ymin <- 0
ymax <- 1

# Establish axis/plot/legend titles:
xlabel <- "Exon number"
ylabel <- "Cumulative fraction"
plot_title <- "Cumulative distribution of exon number for full-length circRNA isoforms across 12 tissues"
legend_title <- "BSJ-FSJ category"

# Establish line widths and font features
line_size <- 1
font_size <- 15
font_family <- "sans"
font_color <- "black"

# Create plot:
p <- ggplot(finalDF, aes(blockCount, color=cate)) + stat_ecdf(size=line_size) + xlab(xlabel) + ylab(ylabel) + ggtitle(plot_title)
q <- p + scale_x_continuous(limit=c(xmin,xmax), breaks=seq(xmin,xmax, by=5)) + scale_y_continuous(limit=c(ymin,ymax), breaks=seq(ymin,ymax, by=0.25))
r <- q + theme(text=element_text(size=font_size, family=font_family), plot.title = element_text(hjust = 0.5), legend.position= "right", axis.text=element_text(color=font_color))
s <- r + scale_color_manual(values=c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#000000"), name=legend_title)

ggsave(output, plot=s, dpi=300, width=12.2, height=6)