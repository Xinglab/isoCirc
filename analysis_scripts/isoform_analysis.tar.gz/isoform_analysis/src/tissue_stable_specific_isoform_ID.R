#!/usr/bin/Rscript

# Libraries:
suppressMessages(library(dplyr))
suppressMessages(library(reshape2))
suppressMessages(library(stringr))
suppressMessages(library(tidyr))
suppressMessages(library(parallel))

# Parse command-line arguments
args = commandArgs(trailingOnly=TRUE)
input = args[1]
outputPrefix = args[2]
numCores = as.numeric(args[3])

# Establish output file names
stableOutFileName <- paste(outputPrefix,"tissue_stable_isoforms.tsv",sep=".")
specificOutFileName <- paste(outputPrefix,"tissue_specific_isoforms.tsv",sep=".")

# Read isoCirc output as a data frame
df <- read.table(input,sep="\t",header=TRUE)
subsetDF <- df %>% select(isoformID, geneName, BSJCate, FSJCate, Adipose:Testis)

# Filter out isoforms that have NA gene assignment
subsetDF <- subsetDF[!(is.na(subsetDF$geneName)),]

# Determine the number of isoforms per gene
lolGeneNames <- strsplit(as.character(subsetDF$geneName),",")
lolIsoformID <- strsplit(as.character(subsetDF$isoformID),",")
geneNames <- unlist(lolGeneNames)
isoformCountDF <- as.data.frame(table(geneNames))
colnames(isoformCountDF) <- c("gene", "numberOfIsoforms")

# Only keep genes that have at least 2 circRNA isoforms
gene_list <- as.character(isoformCountDF[isoformCountDF$numberOfIsoforms >= 2,]$gene)

# Identification of genes with tissue stable isoforms:

# Helper function to retrieve BSJ-FSJ classification of isoform by ID
get_BSJ_FSJ <- function(id) {
	rowIdx <- which(unlist(lapply(lolIsoformID, function(x) id %in% x)))
	BSJ <- as.character(subsetDF[rowIdx,3])
	FSJ <- as.character(subsetDF[rowIdx,4])
	return(c(BSJ,FSJ))
}

# Helper function to retrieve read count matrix for circRNA isoforms of a given gene
get_gene_matrix <- function(gene_name) {
	rowIndices <- which(unlist(lapply(lolGeneNames, function(x) gene_name %in% x)))
	geneDF <- subsetDF[rowIndices,] %>% select(isoformID, Adipose:Testis)
	geneDF <- as.data.frame(geneDF %>% mutate(isoformID = strsplit(as.character(isoformID), ",")) %>% unnest() %>% filter(isoformID != "") %>% select(isoformID, Adipose:Testis) %>% subset(., grepl(paste(gene_name,"circRNA",sep="."),isoformID)))
	geneMatrix <- data.matrix(geneDF %>% select(Adipose:Testis))
	rownames(geneMatrix) <- as.character(geneDF$isoformID)
	return(geneMatrix)
}

# Helper function to compute isoform proportion matrix for circRNA isoforms of a given gene
get_prop_matrix <- function(geneMatrix) {
	propMatrix <- data.matrix(geneMatrix)
	for(tissue in c("Adipose", "Adrenal", "Blood", "Brain", "Heart", "Kidney", "Liver", "Lung", "Prostate", "SkeletalMuscle", "SmoothMuscle", "Testis")) {
		totalReads <- sum(propMatrix[,tissue])
		if(totalReads == 0) {
			propMatrix[,tissue] <- rep(0, nrow(propMatrix))
		}
		else {
			propMatrix[,tissue] <- propMatrix[,tissue]/totalReads
		}
	}
	return(propMatrix)
}

# Function to identify tissue-stable isoforms 
get_stable_isoforms <- function(gene_name) {
	geneMatrix <- get_gene_matrix(gene_name)
	propMatrix <- get_prop_matrix(geneMatrix)
	# Enforce requirement that the tissue-stable isoform has isoform read count proportion greater than 50%
	checkStable <- apply(propMatrix,1,min)>0.5
	if(any(checkStable)) {
		isoformID <- rownames(propMatrix)[which(checkStable)]
		numIsoforms <- nrow(propMatrix)
		min12tissuesPercentage <- min(propMatrix[isoformID,])
		min12tissuesReadCounts <- min(geneMatrix[isoformID,])
		bsj_fsj <- get_BSJ_FSJ(isoformID)
		# Require that the read count of the tissue-stable isoform is >= 2 across all 12 tissues
		if(min(geneMatrix[isoformID,]) >= 2) {
			info <- c(gene_name, numIsoforms, isoformID, min12tissuesPercentage, min12tissuesReadCounts, bsj_fsj)
			return(paste(info, collapse=","))
		}
		else{
			return(NA)
		}
	}
	else{
		return(NA)
	}
}

stable_results <- mclapply(gene_list, get_stable_isoforms, mc.cores = numCores)
stable_results <- stable_results[!is.na(stable_results)]

if(length(stable_results) > 0) {
	stableDF <- data.frame(do.call("rbind", strsplit(unlist(stable_results), ",")))
	# Write the following information into file containing tissue-stable isoforms:
	#	1. gene name
	#	2. number of detected circRNA isoforms
	#	3. an isoform ID
	#	4. the minimum read count proportion of the tissue-stable isoform across all 12 tissues
	#	5. the minimum read count of the tissue-stable isoform across all 12 tissues
	#	6. BSJ category of the tissue-stable isoform
	#	7. FSJ category of the tissue-stable isoform
	colnames(stableDF) <- c("gene", "numIsoforms", "isoformID", "min12tissues_percentage", "min12tissues_readCounts", "BSJCate", "FSJCate")
	stableDF[,"gene"] <- as.character(stableDF[,"gene"])
	stableDF[,"isoformID"] <- as.character(stableDF[,"isoformID"])
	stableDF[,"BSJCate"] <- as.character(stableDF[,"BSJCate"])
	stableDF[,"FSJCate"] <- as.character(stableDF[,"FSJCate"])
	stableDF[,"numIsoforms"] <- as.numeric(as.character(stableDF[,"numIsoforms"]))
	stableDF[,"min12tissues_percentage"] <- as.numeric(as.character(stableDF[,"min12tissues_percentage"]))
	stableDF[,"min12tissues_readCounts"] <- as.numeric(as.character(stableDF[,"min12tissues_readCounts"]))
	write.table(stableDF, file=stableOutFileName, quote=FALSE, sep='\t', row.names=FALSE)
}

# Identification of genes with tissue specific isoforms:

# Function to identify genes harboring potentially tissue-specific isoforms
get_specific_genes <- function(gene_name) {
	geneMatrix <- get_gene_matrix(gene_name)
	propMatrix <- get_prop_matrix(geneMatrix)
	
	# Eliminate columns with no read counts
	viable_tissues_idx <- which(colSums(geneMatrix)!=0)
	propMatrix <- propMatrix[,viable_tissues_idx]
	geneMatrix <- geneMatrix[,viable_tissues_idx]
	
	# Identification of genes with tissue-enriched isoforms
	if(length(viable_tissues_idx) >= 2) {
		# Perform a Chi-Square Test of Homogeneity
		pVal <- chisq.test(geneMatrix)$p.value
		return(paste(c(gene_name, pVal), collapse=","))
	}
	# Identification of genes with tissue-exclusive isoforms
	else {
		return(paste(c(gene_name, 0), collapse=","))
	}
}

gene_pVal <- mclapply(gene_list, get_specific_genes, mc.cores = numCores)
gene_pVal <- gene_pVal[!is.na(gene_pVal)]

gene_pVal_DF <- data.frame(do.call("rbind", strsplit(unlist(gene_pVal), ",")))
colnames(gene_pVal_DF) <- c("gene", "p.value")
gene_pVal_DF[,"gene"] <- as.character(gene_pVal_DF[,"gene"])
gene_pVal_DF[,"p.value"] <- as.numeric(as.character(gene_pVal_DF[,"p.value"]))

# Selection of genes harboring potentially tissue-specific isoforms using FDR < 5%
gene_pVal_DF[,"p.value"] <- p.adjust(gene_pVal_DF$p.value, method="hochberg")
filtered_genes <- gene_pVal_DF[gene_pVal_DF$p.value < 0.05,]$gene

# Function to identify tissue-specific isoforms
get_specific_isoforms <- function(gene_name) {
	geneMatrix <- get_gene_matrix(gene_name)
	propMatrix <- get_prop_matrix(geneMatrix)
	# Eliminate columns with no read counts
	viable_tissues_idx <- which(colSums(geneMatrix)!=0)
	# Identification of tissue-enriched isoforms
	if(length(viable_tissues_idx) >= 2) {
		propMatrix <- propMatrix[,viable_tissues_idx]
		geneMatrix <- geneMatrix[,viable_tissues_idx]
		# Perform an exact binomial test for each cell
		null_proportions <- rowSums(geneMatrix)/sum(geneMatrix)
		tissueReadCounts <- colSums(geneMatrix)
		numIsoforms <- nrow(geneMatrix)
		numTissues <- ncol(geneMatrix)
		pValueMatrix <- matrix(, nrow = numIsoforms, ncol = numTissues)
		for(i in 1:numIsoforms) {
			for(j in 1:numTissues) {
				pValueMatrix[i,j] <- binom.test(geneMatrix[i,j], tissueReadCounts[j], p=null_proportions[i], alternative="greater")$p.value
			}
		}
		# Selection of isoforms using FDR < 5%
		pValueMatrix <- matrix(p.adjust(pValueMatrix, method="hochberg"), nrow=numIsoforms, ncol=numTissues)
		rownames(pValueMatrix) <- rownames(geneMatrix)
		colnames(pValueMatrix) <- colnames(geneMatrix)
		tissue_specific_arridx <- which(pValueMatrix < 0.05, arr.ind = TRUE)
		returnString <- c()
		if(nrow(tissue_specific_arridx) > 0) {
			for(i in 1:nrow(tissue_specific_arridx)) {
				isoformID <- rownames(pValueMatrix)[tissue_specific_arridx[i,1]]
				tissue <- colnames(pValueMatrix)[tissue_specific_arridx[i,2]]
				isoformPercentage <- propMatrix[isoformID, tissue]
				isoformReadCount <- geneMatrix[isoformID, tissue]
				bsj_fsj <- get_BSJ_FSJ(isoformID)
				# Requirement that the tissue-enriched isoform has a read count >= 2 in the given tissue
				if(isoformReadCount >= 2) {
					# Requirement that the difference in isoform proportion for the tissue-enriched isoform against other tissues is >= 5%
					if(all(isoformPercentage - propMatrix[isoformID,][-tissue_specific_arridx[i,2]] >= 0.05)) {
						# Adjusted p-value from Benjamini Hochberg
						pValue <- pValueMatrix[isoformID, tissue]
						id_info <- c(gene_name, numIsoforms, isoformID, tissue, isoformPercentage, isoformReadCount, pValue, bsj_fsj, "ENRICHED")
						returnString <- c(returnString, paste(id_info, collapse=","))
					}
				}
			}
		}
		if(length(returnString) == 0) {
			return(NA)
		}
		else {
			return(paste(returnString, collapse=";"))
		}
	}
	# Identification of tissue-exclusive isoforms
	else {
		tissue <- colnames(geneMatrix)[viable_tissues_idx]
		isoforms <- rownames(geneMatrix)
		numIsoforms <- nrow(geneMatrix)
		geneMatrix <- geneMatrix[,viable_tissues_idx]
		propMatrix <- propMatrix[,viable_tissues_idx]
		returnString <- c()
		for(id in isoforms) {
			isoformPercentage <- propMatrix[id]
			isoformReadCount <- geneMatrix[id]
			bsj_fsj <- get_BSJ_FSJ(id)
			id_info <- c(gene_name, numIsoforms, id, tissue, isoformPercentage, isoformReadCount, 0, bsj_fsj, "EXCLUSIVE")
			returnString <- c(returnString, paste(id_info, collapse=","))
		}
		return(paste(returnString, collapse=";"))
	}
}

specific_results <- mclapply(filtered_genes, get_specific_isoforms, mc.cores = numCores)
specific_results <- specific_results[!is.na(specific_results)]

if(length(specific_results) > 0) {
	specific_results <- unlist(strsplit(unlist(specific_results), ";"))
	specificDF <- data.frame(do.call("rbind", strsplit(specific_results, ",")))
	colnames(specificDF) <- c("gene", "numIsoforms", "isoformID", "tissue", "isoform_percentage", "isoform_readCounts", "adjusted_p.value", "BSJCate", "FSJCate", "status")
	# Write the following information into file containing tissue-specific isoforms:
	#	1. gene name
	#	2. number of detected circRNA isoforms
	#	3. an isoform ID
	#	4. tissue associated with the isoform
	#	5. the read count proportion of the tissue-specific isoform
	#	6. the read count of the tissue-specific isoform
	#	7. p-value for testing whether an isoform were tissue-specific (adjusted by Benjamini-Hochberg)
	#	8. BSJ category of the tissue-stable isoform
	#	9. FSJ category of the tissue-stable isoform
	#	10. subclassification of tissue-specific isoform as either: (1) tissue-exclusive or (2) tissue-enriched (see definitions in Methods)
	specificDF[,"gene"] <- as.character(specificDF[,"gene"])
	specificDF[,"isoformID"] <- as.character(specificDF[,"isoformID"])
	specificDF[,"tissue"] <- as.character(specificDF[,"tissue"])
	specificDF[,"BSJCate"] <- as.character(specificDF[,"BSJCate"])
	specificDF[,"FSJCate"] <- as.character(specificDF[,"FSJCate"])
	specificDF[,"status"] <- as.character(specificDF[,"status"])
	specificDF[,"numIsoforms"] <- as.numeric(as.character(specificDF[,"numIsoforms"]))
	specificDF[,"isoform_percentage"] <- as.numeric(as.character(specificDF[,"isoform_percentage"]))
	specificDF[,"isoform_readCounts"] <- as.numeric(as.character(specificDF[,"isoform_readCounts"]))
	specificDF[,"adjusted_p.value"] <- as.numeric(as.character(specificDF[,"adjusted_p.value"]))
	write.table(specificDF, file=specificOutFileName, quote=FALSE, sep='\t', row.names=FALSE)
}