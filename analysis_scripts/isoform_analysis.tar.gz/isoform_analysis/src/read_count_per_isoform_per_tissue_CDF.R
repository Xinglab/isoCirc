#!/usr/bin/Rscript

# This is a script for visualizing the distribution of read counts per circRNA isoform per tissue as a CDF
#	Isoforms are grouped based on categorizations of their BSJ/FSJs as follows:
#	* FSM/NIC - FSM/NIC
#	* FSM/NIC - NNC
#	* NNC - FSM/NIC
#	* NNC - NNC
#	* combined	
#
# For definitions of BSJ/FSJ categories, refer to the IsoCirc GitHub.
# Only circRNA isoforms with a valid gene assignment are plotted.
# The resulting output is a PDF

# Libraries:
suppressMessages(library(ggplot2))
suppressMessages(library(dplyr))
suppressMessages(library(reshape2))
suppressMessages(library(grid))
suppressMessages(library(gridExtra))
options(scipen = 0)

# Main:

# Parse command-line arguments
args = commandArgs(trailingOnly=TRUE)
input = args[1]
output = args[2]

#input = "isoCirc_hg19_12Tissues.isocirc.out"
#output = "isoCirc_hg19_12Tissues.read_count_per_isoform_per_tissue_CDF.pdf"

# Read IsoCirc pipeline output as a data frame
df <- read.table(input,sep="\t",header=TRUE)

# Filter data frame for cases where there is a 'NA' gene assignment
#df <- df[!(is.na(df$geneName)),]

# Compute total number of reads combined across 12 tissues
combinedReadCount <- rowSums(df %>% select(Adipose:Testis))

# Function to plot the distribution of read counts per isoform per tissue as a CDF
tissue_reads_per_isoform <- function(tissue) {

# Create a smaller data frame consisting of (1) BSJ category, (2) FSJ category, (3) read counts belonging to a tissue
subsetDF <- df %>% select(BSJCate, FSJCate, tissue) 

# Select isoforms in which the tissue read count >= 2
subsetDF <- subsetDF[subsetDF[[tissue]]>=2,]

# Collapse to create BSJ-FSJ feature
subsetDF$cate <- paste(subsetDF$BSJCate, subsetDF$FSJCate, sep="-")

# Create a new category for combined
copySubsetDF <- data.frame(subsetDF)
copySubsetDF$cate <- rep("All-All", nrow(copySubsetDF))

finalDF <- data.frame()
finalDF <- rbind(finalDF, copySubsetDF)
colnames(finalDF) <- colnames(subsetDF)

# FSM/NIC-FSM/NIC 
tmpDF <- subsetDF[subsetDF$cate=="FSM-FSM" | subsetDF$cate=="NIC-FSM" | subsetDF$cate=="FSM-NIC" | subsetDF$cate=="NIC-NIC",]
tmpDF$cate <- rep("FSM/NIC-FSM/NIC",nrow(tmpDF))
finalDF <- rbind(finalDF, tmpDF)

#FSM/NIC-NNC
tmpDF <- subsetDF[subsetDF$cate=="FSM-NNC" | subsetDF$cate=="NIC-NNC",]
tmpDF$cate <- rep("FSM/NIC-NNC", nrow(tmpDF))
finalDF <- rbind(finalDF, tmpDF)

# NNC-FSM/NIC
tmpDF <- subsetDF[subsetDF$cate=="NNC-FSM" | subsetDF$cate=="NNC-NIC",]
tmpDF$cate <- rep("NNC-FSM/NIC", nrow(tmpDF))
finalDF <- rbind(finalDF, tmpDF)

#NNC/NNC
finalDF <- rbind(finalDF, subsetDF[subsetDF$cate=="NNC-NNC",])

# Annotate each label by counts
countDF <- data.frame(table(finalDF$cate))
colnames(countDF) <- c("class", "count")
finalDF$cate <- unlist(lapply(finalDF$cate, function(x) paste(x, paste("(",paste(as.character(format(countDF[countDF$class == x,]$count, big.mark = ",", scientific = FALSE)), ")", sep=""), sep=""), sep=" ")))

finalDF$cate <- as.factor(finalDF$cate)
finalDF$cate <- factor(finalDF$cate, levels = c(levels(finalDF$cate)[-1], levels(finalDF$cate)[1]))

colnames(finalDF)[3] <- "tissueReads"

# Establish plot theme:
theme_jack <- function (base_size = 12, base_family = "") {
theme_gray(base_size = base_size, base_family = base_family) %+replace%
  theme(
    panel.background = element_rect(fill=NULL),
    panel.grid.minor.y = element_line(size=0),
    panel.grid.minor.x = element_line(size=0),
    panel.grid.major = element_line(colour = "grey80",size=.2)
  )
}
theme_set(theme_jack())

# Establish axis limits:

xmin <- 10^floor(log(min(combinedReadCount), 10))
xmax <- 10^ceiling(log(max(combinedReadCount), 10)) 
ymin <- 0
ymax <- 1

# Establish axis/plot/legend titles:
plot_title <- tissue
legend_title <- "BSJ-FSJ Category"

# Establish line widths and font features
line_size <- 1
font_size <- 15
font_family <- "sans"
font_color <- "black"

# Create plot:
p <- ggplot(finalDF, aes(tissueReads, color=cate)) + stat_ecdf(size=line_size) + ggtitle(plot_title)
q <- p + scale_x_continuous(limits=c(xmin,0.2*xmax), breaks=c(1, 10^seq(log10(xmin),log10(xmax)-1),0.2*xmax), trans="log10", labels=function(x) format(x, scientific = TRUE)) + scale_y_continuous(limit=c(ymin,ymax), breaks=seq(ymin,ymax, by=0.25))
r <- q + theme(text=element_text(size=font_size, family=font_family), plot.title = element_text(hjust = 0.5), legend.position= "right", axis.text=element_text(color=font_color), axis.text.x=element_text(angle=45, hjust=1), axis.title.x=element_blank(), axis.title.y=element_blank())
s <- r + scale_color_manual(values=c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#000000"), name=legend_title)
return(s)

}

p1 <- tissue_reads_per_isoform("Adipose")
p2 <- tissue_reads_per_isoform("Adrenal")
p3 <- tissue_reads_per_isoform("Blood")
p4 <- tissue_reads_per_isoform("Brain")
p5 <- tissue_reads_per_isoform("Heart")
p6 <- tissue_reads_per_isoform("Kidney")
p7 <- tissue_reads_per_isoform("Liver")
p8 <- tissue_reads_per_isoform("Lung")
p9 <- tissue_reads_per_isoform("Prostate")
p10 <- tissue_reads_per_isoform("SkeletalMuscle")
p11 <- tissue_reads_per_isoform("SmoothMuscle")
p12 <- tissue_reads_per_isoform("Testis")

top_label <- "Cumulative distribution of read counts for full-length circRNA isoforms in individual tissues"
x_label <- "Read count"
y_label <- "Cumulative fraction"

g <- arrangeGrob(p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,nrow=6,top=textGrob(top_label, gp=gpar(cex=1.5)),bottom=textGrob(x_label, gp=gpar(cex=1.5)), left=textGrob(y_label, gp=gpar(cex=1.5), rot=90))
ggsave(output, plot=g, dpi=300, width=17, height=22)