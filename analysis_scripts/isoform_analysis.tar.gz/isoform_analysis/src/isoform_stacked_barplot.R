#!/usr/bin/Rscript

# This is a script for visualizing the relative proportions of circRNA isoforms of a gene across all 12 tissues
#	Only isoforms where the BSJ and FSJ are not classified as NNC were plotted
# For definitions of BSJ/FSJ categories, refer to the IsoCirc GitHub.
# The resulting output is a PDF

# Libraries:
suppressMessages(library(ggplot2))
suppressMessages(library(dplyr))
suppressMessages(library(stringr))
suppressMessages(library(reshape2))
suppressMessages(library(RColorBrewer))
suppressMessages(library(tidyr))
suppressMessages(library(data.table))

# Parse command-line arguments
args = commandArgs(trailingOnly=TRUE)
input_file = args[1]
gene_name = args[2]
output = args[3]

#input_file <- "isoCirc_hg19_12Tissues.isocirc.withID.out"
#gene_name <- "KDM1A"
#output <- "isoCirc_hg19_12Tissues.stacked_barplot.KDM1A.pdf"

# Read IsoCirc pipeline output as a data frame
df <- read.table(input_file,sep="\t",header=TRUE)

# Filter data frame for cases where there is a 'NA' gene assignment
df <- df[!(is.na(df$geneName)),]

# Only plot isoforms where neither the BSJ or FSJ is classified as NNC
df <- df[!(df$BSJCate=="NNC" | df$FSJCate=="NNC"),]

# Selection of isoforms mapping to gene of interest
lolGeneNames <- strsplit(as.character(df$geneName),",")
rowIndices <- which(unlist(lapply(lolGeneNames, function(x) gene_name %in% x)))
geneDF <- df[rowIndices,] %>% select(isoformID, Adipose:Testis)
geneDF <- as.data.frame(geneDF %>% mutate(isoformID = strsplit(as.character(isoformID), ",")) %>% unnest() %>% filter(isoformID != "") %>% select(isoformID, Adipose:Testis) %>% subset(., grepl(paste(gene_name,"circRNA",sep="."),isoformID)))

# Calculation of tissue read count over all high-confidence isoforms
countDF <- as.data.frame(geneDF %>% select(Adipose:Testis) %>% colSums(.))
countDF <- as.data.frame(setDT(countDF, keep.rownames = TRUE)[])
colnames(countDF) <- c("tissue", "readCount")
colnames(geneDF) <- c("isoformID", paste(paste(paste(countDF$tissue, " (", sep=""), as.character(countDF$readCount), sep=""), ")", sep=""))

# Establish color palette for number of isoforms
colorCount <- nrow(geneDF)
getPalette <- colorRampPalette(brewer.pal(9, "Set1"))

# Compute the relative abundance of isoforms in each tissue
for(tissue in colnames(geneDF)[2:length(colnames(geneDF))]) {
	totalReads <- sum(geneDF[[tissue]])
	if(totalReads == 0) {
		geneDF[[tissue]] <- 0
	}
	else {
		geneDF[[tissue]] <- geneDF[[tissue]]/sum(geneDF[[tissue]])
	}
}
geneDF <- melt(geneDF, id.vars=c("isoformID"), variable.name = "tissue", value.name="proportion")

# Re-ordering of factors
geneDF$isoformID <- factor(geneDF$isoformID, levels=paste(paste(gene_name,"circRNA.",sep="."),paste(seq(1,length(geneDF$isoformID),1)),sep=""))

# Establish plot theme:
theme_jack <- function (base_size = 12, base_family = "") {
theme_gray(base_size = base_size, base_family = base_family) %+replace%
  theme(
    panel.background = element_rect(fill=NULL),
    panel.grid.minor.y = element_line(size=0),
    panel.grid.minor.x = element_line(size=0),
    panel.grid.major = element_line(colour = "grey80",size=.2)
  )
}
theme_set(theme_jack())

# Establish axis limits:
ymin <- 0
ymax <- 1

# Establish axis/plot/legend titles:
xlabel <- ""
ylabel <- "circRNA isoform proportion"
legend_title <- paste(gene_name, "circRNA isoforms", sep=" ")

# Establish line widths and font features
line_size <- 1
font_size <- 15
font_family <- "sans"
font_color <- "black"

# Establish color palette
set.seed(111)
color_choices <- sample(getPalette(colorCount))

# Customized color palettes for figures in the paper

# Color palettes: METTL3, HIPK3, UBXN7, UBE2G1
#set.seed(111)
#color_choices <- sample(getPalette(colorCount))

# Color palettes: KDM1A
#set.seed(106)
#color_choices <- sample(getPalette(colorCount))
#color_choices <- replace(color_choices, c(2,8), color_choices[c(8,2)])

# Color palettes: PDE8A
#set.seed(108)
#color_choices <- sample(getPalette(colorCount))
#color_choices <- replace(color_choices, c(3,24), color_choices[c(24,3)])

# Create stacked barplot
p <- ggplot(geneDF, aes(x=tissue, y=proportion, fill=isoformID)) + geom_bar(stat="identity", color="black") + xlab(xlabel) + ylab(ylabel)
q <- p + scale_y_continuous(limit=c(ymin,ymax), breaks=seq(ymin,ymax, by=0.25))
r <- q + theme(text=element_text(size=font_size, family=font_family), legend.title = element_text(face = "bold"), legend.position = "right", axis.text.x=element_text(angle=45, hjust=1, face="bold"))
s <- r + scale_fill_manual(values = color_choices, name=legend_title) 

ggsave(output, plot=s, dpi=300, width=9.3, height=6)