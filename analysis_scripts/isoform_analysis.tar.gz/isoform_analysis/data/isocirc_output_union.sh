#!/bin/bash

# This script will ouput the union of circRNA isoforms between 12 tissue data and HEK293 data
# The script will combine read counts from all six replicates of HEK293 data to create one combined HEK293 sample
# The output file will only include isoforms where there is at least 2 reads in one sample (either 12 tissues or HEK293)

# Establish input arguments
tissuefile="$1"
hek293file="$2"
outname="$3"

# Establish working directories
data=$(dirname "$tissuefile")
isocirc=$(dirname "$data")
tmp="$isocirc/tmp"

mkdir -p "$tmp"

# Establish file header for combined file
head -n 1 "$tissuefile" | sed -e 's/$/\tHEK293/' > "$data/$outname"

# Collapse IsoCirc outputs for 12tissue and HEK293
tail -n +2 "$tissuefile" | cut -f1-4,8,9,33- | perl -pe '$c = 0; s/\t/|/ while $c++ < 5' | rev | perl -pe '$c = 0; s/\t/|/ while $c++ < 11' | rev | awk '{printf("%s\t%s\n","12tissues",$0)}' | paste - <(tail -n +2 "$tissuefile" | cut -f1-32 | tr '\t' '|') > "$tmp/12tissues_HEK293_combined_isocirc.compressed.out"
tail -n +2 "$hek293file" | cut -f1-4,8,9,33- | perl -pe '$c = 0; s/\t/|/ while $c++ < 5' | awk '{sum=0;for(i=2;i<=NF;i++){sum+=$i;}printf("%s\t%s\t%s\n","HEK293",$1,sum)}' | paste - <(tail -n +2 "$hek293file" | cut -f1-32 | tr '\t' '|') >> "$tmp/12tissues_HEK293_combined_isocirc.compressed.out"

# Determine union of both datasets
cut -f2 "$tmp/12tissues_HEK293_combined_isocirc.compressed.out" | sort | uniq | awk '{
	if(FNR==NR) {
		if($1=="12tissues") {
			tissue[$2]=$3;
			tissorig[$2]=$4;
		}
		else{
			hek293[$2]=$3;
			hek293orig[$2]=$4;
		}
	}
	else {
		# Isoforms in both 12 tissue data and HEK293 data
		if($1 in tissue && $1 in hek293){
			rc = tissue[$1]"|"hek293[$1];
			printf("%s\t%s\n",tissorig[$1],rc);
		}
		# Isoforms only in 12 tissue data
		else if($1 in tissue){
			rc = tissue[$1]"|0";
			printf("%s\t%s\n",tissorig[$1],rc);
		}
		# Isoforms only in HEK293 data
		else{
			if(hek293[$1]>=2) {
				rc="0|0|0|0|0|0|0|0|0|0|0|0|"hek293[$1];
				printf("%s\t%s\n",hek293orig[$1],rc);
			}
		}
	}
}' "$tmp/12tissues_HEK293_combined_isocirc.compressed.out" - | tr '|' '\t' >> "$data/$outname"

rm "$tmp/12tissues_HEK293_combined_isocirc.compressed.out"
rmdir "$tmp"
